#include <stdlib.h>
#include <stdio.h>
#include "es16.h"

/*
 * Per compilare usare il comando:
 *   gcc -std=gnu89 -Wall -pedantic -o es16 es16.c es16_main.c
 */
int main() {
    return EXIT_SUCCESS;
}
