#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "es16.h"

struct frequenze* leggi_parole(char *path, int *dim) {
    return NULL;
}

int scrivi_parole(char *path, struct frequenze *v, int dim) {
    return -1;
}
