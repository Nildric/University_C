#include <stdlib.h>
#include <stdio.h>
#include "es17.h"

/*
 * Per compilare usare il seguente comando:
 *   gcc -std=gnu89 -Wall -pedantic -o es17 es17.c es17_main.c
 */
int main() {
    return EXIT_SUCCESS;
}
