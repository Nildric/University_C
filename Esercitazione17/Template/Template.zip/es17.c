#include <stdlib.h>
#include <string.h>
#include "es17.h"

int ordinata(ListaS l) {

}

void inserisci(ListaS *l, char *s) {

}

void rimuovi_duplicati(ListaS l) {

}
