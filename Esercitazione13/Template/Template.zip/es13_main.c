#include <stdlib.h>
#include <stdio.h>
#include "es13.h"

/*
 * Per compilare usare il comando
 *   gcc -std=gnu89 -Wall -pedantic -o es13 es13.c es13_main.c
 */
int main() {
    return EXIT_SUCCESS;
}
