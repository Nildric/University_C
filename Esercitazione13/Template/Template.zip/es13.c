#include <string.h>
#include "es13.h"

int ricerca(int v[], int val, int inf, int sup) {
    return -1;
}

int palindroma(char *s) {
    return -1;
}

int zaino(int pesi[], int n, int p) {
    return -1;
}
