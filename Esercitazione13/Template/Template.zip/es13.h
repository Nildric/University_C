#ifndef ES13_H
#define ES13_H

int ricerca(int v[], int val, int inf, int sup);
int palindroma(char *s);
int zaino(int pesi[], int n, int p);

#endif
