#ifndef ES14_H
#define ES14_H
#define N 20

int conta_combinazioni(int v[], int n, int somma);
int percorso_minimo(int m[N][N], int n);

#endif
