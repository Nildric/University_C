#include <stdlib.h>
#include <stdio.h>
#include "es14.h"

/*
 * Per compilare usate il comando:
 *   gcc -std=gnu89 -Wall -pedantic -o es14 es14.c es14_main.c
 */
int main() {
    return EXIT_SUCCESS;
}
