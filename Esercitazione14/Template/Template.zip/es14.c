#include "es14.h"

int conta_combinazioni(int v[], int n, int somma) {
    return -1;
}

int percorso_minimo(int m[N][N], int n) {
    return -1;
}
