#include <stdlib.h>
#include <stdio.h>
#include "es12.h"

/*
 * Per compilare usate il comando
 *   gcc -std=gnu89 -Wall -pedantic -o es12 es12.c es12_main.c
 */
int main() {
    return EXIT_SUCCESS;
}
