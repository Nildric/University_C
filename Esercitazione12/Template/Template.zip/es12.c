#include "es12.h"

void conta_segno(int v[], int n, int *npos, int *nneg, int *nzero) {

}

void differenza_frazioni(int n1, int d1, int n2, int d2, int *ndiff, int *ddiff) {

}

void str2dec(char s[], int *i, int *d, int *e) {

}
