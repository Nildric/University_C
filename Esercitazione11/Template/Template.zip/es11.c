#include "es11.h"

void str2vet(char mano[], int valori_carte[SIZE], char semi[SIZE]) {

}

int punteggio_mano(char mano[]) {
    return CARTA_ALTA;
}

int vincitore(char m1[], char m2[]) {
    return -1;
}
