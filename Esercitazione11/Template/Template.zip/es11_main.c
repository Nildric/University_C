#include <stdlib.h>
#include <stdio.h>
#include "es11.h"

/* Scrivere il main di prova in questo file e compilare con il
 * seguente comando:
 *   gcc -std=gnu89 -Wall -pedantic -o es11 es11.c es11_main.c
 */
int main() {
    return EXIT_SUCCESS;
}
