#include <stdlib.h>
#include "es15.h"

void aggiungi(struct insieme *pin, int v[], int n) {

}

struct insieme* intersezione(struct insieme in1, struct insieme in2) {
    return NULL;
}

struct insieme* unione(struct insieme in1, struct insieme in2) {
    return NULL;
}
