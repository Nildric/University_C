#include <stdlib.h>
#include <stdio.h>
#include "es15.h"

/*
 * Per compilare usare il comando:
 *   gcc -std=gnu89 -Wall -pedantic -o es15 es15.c es15_main.c
 */
int main() {
    return EXIT_SUCCESS;
}
