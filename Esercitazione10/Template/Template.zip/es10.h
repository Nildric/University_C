#ifndef ES10_H

int is_prime(int n);
int next_prime(int n);
void print_factors(int n);

#endif
