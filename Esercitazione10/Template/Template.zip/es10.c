#include <stdlib.h>
#include <stdio.h>
#include "es10.h"

int is_prime(int n) {
	return 0;
}

int next_prime(int n) {
	return 0;
}

void print_factors(int n) {}
